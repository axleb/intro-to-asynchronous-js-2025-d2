import { Observable } from 'rxjs';
const observable = new Observable((s)=>{
  s.next("Hello");
  s.next("from");
  s.next("Skillsoft");
});
//
observable.subscribe({
  next(data) { 
    console.log(data); 
  }
});

